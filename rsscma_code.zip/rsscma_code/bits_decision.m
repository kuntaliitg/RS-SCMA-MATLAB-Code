
%% Convert LLRs to hard bits
function[hard_bits]=bits_decision(LLRs,len)
        hard_bits = zeros(1,len); % Preallocate array for hard bits

        % Loop through each LLR value
        for k = 1:size(LLRs, 1)
            % Hard decision for MSB
            if LLRs(k, 1) > 0
                hard_bits(2*k - 1) = 0; % Set MSB to 0 if LLR is positive
            else
                hard_bits(2*k - 1) = 1; % Set MSB to 1 if LLR is negative
            end

            % Hard decision for LSB
            if LLRs(k, 2) > 0
                hard_bits(2*k) = 0; % Set LSB to 0 if LLR is positive
            else
                hard_bits(2*k) = 1; % Set LSB to 1 if LLR is negative
            end
        end
end