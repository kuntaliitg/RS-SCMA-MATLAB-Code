function symbols = bits_to_sym_grey(bits)
    % Validate that input is a 2-column matrix (each row is a pair of bits)
    if size(bits, 2) ~= 2
        error('Input must be a matrix with 2 columns representing bit pairs');
    end
%[1+1j, 1-1j, -1-1j, -1+1j]
%[1+1j, -1+1j, -1-1j, 1-1j]
    % Initialize symbols array
    symbols = zeros(size(bits, 1), 1);

    % Convert each bit pair to a symbol based on the specified mapping
    for i = 1:size(bits, 1)
        if isequal(bits(i, :), [0 0])
            symbols(i) = 1; % 00 -> 1
        elseif isequal(bits(i, :), [0 1])
            symbols(i) = 2; % 01 -> 2
        elseif isequal(bits(i, :), [1 1])
            symbols(i) = 3; % 11 -> 3
        elseif isequal(bits(i, :), [1 0])
            symbols(i) = 4; % 10 -> 4
        else
            error('Invalid bit pair at row %d', i);
        end
    end
end