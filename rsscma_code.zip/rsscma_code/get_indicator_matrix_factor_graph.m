function F=get_indicator_matrix_factor_graph(C, J, K)
F=zeros(K,J);
for j=1:J
    current_vector=C((j-1)*K+1:j*K,1);
    non_zero_indices= find(current_vector);
    F(non_zero_indices,j)=1;
end