%% qpsk modulation in terms of grey codes
function[symbols]= qpsk_mod_grey(bits)
% Define QPSK Gray-coded constellation
mapping = [1+1j, -1+1j, -1-1j, 1-1j] / sqrt(2);

bit_pairs = [0 0; 0 1; 1 1; 1 0]; % Gray coding for QPSK
symbols = zeros(1, length(bits) / 2);
for i = 1:2:length(bits)
    bit_pair = bits(i:i+1); % Take two bits at a time
    % Find the corresponding symbol in the Gray-coded constellation
    index = find(ismember(bit_pairs, bit_pair, 'rows'));
    symbols((i+1)/2) = mapping(index);
end