%% RS-SCMA Downlink BER Simulation
% This is the MATLABcode for the paper "Hybrid Rate-Splitting and Sparse Code Multiple Access(RS-SCMA): Design and Performance" authored by  Minerva Priyadarsini, Zilong Liu, Kuntal Deka, Sujit Kumar Sahoo, and Sanjeev Sharma
  
% -------------------------------------------------------------------------
% What this script does:
%   1) Generates random bits for J users (private) and K common QPSK symbols
%   2) Superposes:  y = h .* ( sqrt(P1)*s_common + sum_j sqrt(P2)*x_j ) + n
%   4) Decodes common QPSK -> soft symbols -> SIC
%   5) SCMA MPA detection on residual for private symbols
%   6) Computes BER (bit error rate) for:
%        - common bits (all K REs)
%        - private bits (all J users)
%      and reports an overall BER (average of the two pools)
%
% Notes:
%   - Uses your existing helper functions:
%       get_indicator_matrix_factor_graph
%       qpsk_mod_grey, qpsk_demod_llr_grey (or soft_bits_LLR)
%       bits_decision, bits_to_sym_grey
%       SCMA_detection_MPA_LLR_domain_mex
%   - Expects codebook matrix C loaded from .mat (K*J x M)
%  
% -------------------------------------------------------------------------


clc;
close all;
clear all;

%% ---------------------- 1) Basic Parameters ----------------------------
J = 6;
N = 60000;
K = 4;
dv = 2;
M = 4;
m = log2(M);

Eb_N0_dB = 0:6:30;
noiseVar = 10.^(-Eb_N0_dB/10);     
Eb_N0    = db2pow(Eb_N0_dB);

max_iter = 10;                           %number of MPA iterations

%% ---------------------- 2) Load Codebook & Graph ------------------------
load('power_imbalance','C');
% load('codebook_J6_K4.mat','C');

F = get_indicator_matrix_factor_graph(C, J, K);

Es = sum(sum((abs(C)).^2)) / length(C);
Eb = Es / m;

N0    = Eb ./ Eb_N0;
sigma = sqrt(N0/2);

BER = zeros(1, length(Eb_N0_dB));
% Gray QPSK mapping 
mapping = [1+1j, 1-1j, -1-1j, -1+1j] / sqrt(2); 

%% ---------------------- 3) Power Allocation (MMF) -----------------------
file_contents=load("power_file.mat");
P2_all_MMF=file_contents.P2_all_MMF;
%% ---------------------- 4) Main Eb/N0 Loop ------------------------------
for e = 1:length(Eb_N0_dB)

    % ---- Error counters ----
    symbol_errors_p = 0;
    symbol_errors_c = 0;

    % ---- Power split ----
    P2 = P2_all_MMF(e);
    P1 = 1 - P2;

    power_levels = [P1 ; P2];
    power_users  = repmat(power_levels, 1, K);

    pow_user_scma   = power_users(2,:);               
    pow_scma        = repmat(power_users(2), 1, J);    % used in MPA mex
    sqrt_power_matrix = sqrt(power_users);

    sqrt_powmat_scma = repmat(sqrt_power_matrix(2,:)', 1, J);
    cf = 1000;                                            % used in MPA for cut-off value 

    % ---- Storage for estimated indices across the frame ----
    symbol_indices_com_est1 = [];
    symbol_indices_pri_est1 = [];
    symbol_indices_pri_est2 = []; 

    %% ------------------ 4.1) Random bit generation -----------------------
    bits_u1 = randi([0 1], N,   m);
    bits_u2 = randi([0 1], N,   m);
    bits_u3 = randi([0 1], N,   m);
    bits_u4 = randi([0 1], N,   m);
    bits_u5 = randi([0 1], N/2, m);
    bits_u6 = randi([0 1], N/2, m);

    %% ------------------ 4.2) Message splitting (50-50) -------------------
    % Common bits from users 1..4
    bit_c1 = bits_u1(1:(50*N/100))';
    bit_c2 = bits_u2(1:(50*N/100))';
    bit_c3 = bits_u3(1:(50*N/100))';
    bit_c4 = bits_u4(1:(50*N/100))';

    % Private bits
    bit_p1 = bits_u1((50*N/100)+1:N)';
    bit_p2 = bits_u2((50*N/100)+1:N)';
    bit_p3 = bits_u3((50*N/100)+1:N)';
    bit_p4 = bits_u4((50*N/100)+1:N)';

    % Users 5..6 private (length matched to user4 private length)
    bit_p5 = bits_u5(1:length(bit_p4))';
    bit_p6 = bits_u6(1:length(bit_p4))';

    bits_c = [bit_c1, bit_c2, bit_c3, bit_c4];
    bits_p = [bit_p1, bit_p2, bit_p3, bit_p4, bit_p5, bit_p6];

    % For SER/BER evaluation you store true indices from mapping
    com_sym = [];
    pri_sym = [];

    %% ------------------ 4.3) Symbol loop (2 bits at a time) --------------
    for i = 1:2:length(bits_c)-1

        % ----- Pick 2-bit chunks (common and private) -----
        bits_cmsg = bits_c(i:i+1, :);
        bits_pmsg = bits_p(i:i+1, :);

        bits_commsg = reshape(bits_cmsg, 1, 2*K);

        % ----- QPSK modulation for common stream -----
        mod_c  = qpsk_mod_grey(bits_commsg);

        % True common symbol index tracking
        sym_indc = bits_to_sym_grey(bits_cmsg');
        com_sym  = [com_sym; sym_indc(1)];

        % True private symbol index tracking
        sym_indp = bits_to_sym_grey(bits_pmsg');
        pri_sym  = [pri_sym; sym_indp(1)];

        %% ---------------- SCMA codeword mapping --------------------------
        SCMA_codewords = zeros(K, J);
        for j = 1:J
            present_codebook = C((j-1)*K+1:j*K, :);  % codebook for user j
            SCMA_codewords(:, j) = present_codebook(:, sym_indp(j));
        end

        qpsk_code = mod_c.';  % Kx1

        %% ---------------- Channel + Noise -------------------------------
        AWGN1 = sigma(e) * (randn(K,1) + 1j*randn(K,1));

        % Downlink channel (per resource)
        h1 = 1/sqrt(2) * (randn(K,1) + 1j*randn(K,1));
        % h1 = ones(K,1);

        h_matrix = repmat(h1, 1, J); 

        %% ---------------- Transmit superposition ------------------------
        % y = h .* ( private_sum + common ) + n
        y11 = h1 .* ( ...
                [sum(sqrt_powmat_scma(2,1) .* SCMA_codewords, 2)] + ...
                sqrt_power_matrix(1)' .* qpsk_code ...
              ) + AWGN1;


        %% ---------------- Equalization --------------------------
        y1 = y11 ./ (h1);

        %% ---------------- Common detection (LLR + hard bits) -------------
        LLRs_com   = soft_bits_LLR(y1, length(bits_commsg), sigma(e)^2);
        est_bits_c = bits_decision(LLRs_com, length(bits_commsg));

        bit_com = reshape(est_bits_c, 2, K);
        symbol_indices_hat_c1 = bits_to_sym_grey(bit_com');

        symbol_indices_com_est1 = [symbol_indices_com_est1; symbol_indices_hat_c1(1)];


        %% ---------------- Hard-SIC reference (kept) ----------------------
        y_rem = qpsk_mod_grey(est_bits_c);          % hard remod
        y_diff_hard = y11 - sqrt_power_matrix(1)' .* y_rem.' .* h1;

  

        %% ---------------- Private detection (MPA mex) --------------------
       
        symbol_indices_hat_p = SCMA_detection_MPA_LLR_domain_mex( ...
            pow_scma, y_diff_hard, N0(e), h_matrix, F, max_iter, M, C, cf);

        symbol_indices_pri_est1 = [symbol_indices_pri_est1; symbol_indices_hat_p(1)];

    end 

    %% ------------------ 4.4) Error counting & BER ------------------------
    split_msg_sym_p = [pri_sym];
    split_msg_sym_c = [com_sym];

    est_symbols_p = [symbol_indices_pri_est1];
    est_symbols_c = [symbol_indices_com_est1];

    error_locations_c = find(est_symbols_c ~= com_sym);
    if ~isempty(error_locations_c)
        symbol_errors_c = symbol_errors_c + length(error_locations_c);
    end
    BER2(e) = (symbol_errors_c/(0.50*N))/2;   

    error_locations_p = find(est_symbols_p ~= pri_sym);
    if ~isempty(error_locations_p)
        symbol_errors_p = symbol_errors_p + length(error_locations_p);
    end
    BER1(e) = (symbol_errors_p/(0.50*N))/2;   

  
    BER = (BER1 + BER2)/2;

    fprintf('\n Simulation done for %d dB', Eb_N0_dB(e));
end % end main loop

%% ---------------------- 5) Plot ----------------------------------------
semilogy(Eb_N0_dB, BER, '-*');
xlabel('SNR in dB');
ylabel('BER');  
grid on;
