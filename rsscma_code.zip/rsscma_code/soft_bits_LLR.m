function [LLRs] = soft_bits_LLR(y1, len,var)
%%% it is ratio between bit 0 and 1
    mapping = [1+1j, -1+1j, -1-1j, 1-1j] / sqrt(2);
    
    LLRs = zeros(len / 2, 2); % Each QPSK symbol has 2 bits

    for k = 1:length(y1)
        rx_symbol = y1(k);

        % Calculate scaled Euclidean distances to each constellation point
        distances = abs(rx_symbol - mapping).^2 ;

        % Compute LLR for MSB (Most Significant Bit)
        LLRs(k, 1) = log(sum(exp(-distances([1, 2]))/(2*var)))-log(sum(exp(-distances([3, 4]))/(2*var)))  ;

        % Compute LLR for LSB (Least Significant Bit)
        LLRs(k, 2) = log(sum(exp(-distances([1, 4]))/(2*var)))-log(sum(exp(-distances([2, 3]))/(2*var)))  ;
    end
end
